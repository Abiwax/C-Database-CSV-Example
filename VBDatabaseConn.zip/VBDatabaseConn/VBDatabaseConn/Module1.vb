﻿'First, Right click On references In your project via solution explorer, 
'click On Add reference, on the left side, click extension, scroll down till you find MySql.Data,
'add it To your project, then continue coding as below.

Imports MySql.Data.MySqlClient

Module Module1

    Dim conn As New MySqlConnection
    Dim DatabaseName As String = "reservation"
    Dim server As String = "localhost"
    Dim userName As String = "root"
    Dim password As String = "password"

    Function connect() As DataTable
        Dim dt As New DataTable()
        If Not conn Is Nothing Then conn.Close()
        conn.ConnectionString = String.Format("server={0}; user id={1}; password={2}; database={3}; pooling=false", server, userName, password, DatabaseName)
        Try
            conn.Open()
            Console.WriteLine("Connected")
            Console.ReadLine()
            Console.WriteLine("Select data")
            Dim cmd As MySqlCommand
            cmd = conn.CreateCommand
            cmd.CommandText = String.Format("SELECT * FROM reservation.student_details;")
            Dim adap As New MySqlDataAdapter
            adap = New MySqlDataAdapter(cmd)
            adap.Fill(dt)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Console.ReadLine()
        End Try
        conn.Close()
        Return dt

    End Function

    Sub Main()
        Dim dt As DataTable
        dt = connect()
        Dim row As DataRow
        Dim column As DataColumn
        For Each row In dt.Rows
            For Each column In dt.Columns
                Console.WriteLine(row(column.ColumnName))
            Next

        Next

        Console.ReadLine()

    End Sub

End Module

